// dnlib: See LICENSE.txt for more info

﻿namespace dnlib.Utils {
	/// <summary>
	/// Extension methods
	/// </summary>
	public static partial class Extensions {
	}
}
