// dnlib: See LICENSE.txt for more info

﻿namespace dnlib.IO {
	/// <summary>
	/// Extension methods
	/// </summary>
	public static partial class IOExtensions {
	}
}
